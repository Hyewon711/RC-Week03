package com.example.myrc_03.model

data class UpdateList(val name:String, var img: String? = null)