package com.example.myrc_03.viewHolder

import android.view.View
import android.view.animation.RotateAnimation
import com.example.myrc_03.model.Category
import com.iamkamrul.expandablerecyclerviewlist.viewholder.ParentViewHolder
import kotlinx.android.synthetic.main.item_category.view.*

class CategoryViewHolder(itemView: View) : ParentViewHolder(itemView) {
    val TAG: String = "로그"
    private lateinit var animation: RotateAnimation
    private val categoryTextView = itemView.tv_category
    private val totalTextView = itemView.tv_total
    private val categoryImageView = itemView.iv_arrow_expand

    fun bind(category: Category){
        categoryTextView.text = category.name
        totalTextView.text = category.getChildItemList().size.toString()
    }

    override fun onExpansionToggled(expanded: Boolean) {
        super.onExpansionToggled(expanded)
        animation = if (expanded)
            RotateAnimation(180f,0f, RotateAnimation.RELATIVE_TO_SELF, 0.5f, RotateAnimation.RELATIVE_TO_SELF, 0.5f)
        else
            RotateAnimation(-1 * 180f,0f, RotateAnimation.RELATIVE_TO_SELF, 0.5f, RotateAnimation.RELATIVE_TO_SELF, 0.5f)

        animation.duration = 200
        animation.fillAfter = true
        categoryImageView.startAnimation(animation)

    }

    override fun setExpanded(expanded: Boolean) {
        super.setExpanded(expanded)
        if (expanded)categoryImageView.rotation = 180f
        else categoryImageView.rotation = 0f
    }
}