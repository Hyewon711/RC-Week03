package com.example.myrc_03.model

data class CategoryList(val name:String, var img: String? = null, var state: String? = null, var song: String? = null )
