package com.example.myrc_03

interface ProfileRecyclerviewInterface {
    fun onItemClicked(position: Int)
}