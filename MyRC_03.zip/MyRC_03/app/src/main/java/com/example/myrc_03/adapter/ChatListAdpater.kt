package com.example.myrc_03.adapter

import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.myrc_03.R
import com.example.myrc_03.model.ChatList
import com.example.myrc_03.viewHolder.ChatListViewHolder

class ChatListAdpater: RecyclerView.Adapter<ChatListViewHolder>() {
    val TAG: String = "로그"
    private var chatList = ArrayList<ChatList>()


    // 뷰홀더가 생성 될때
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChatListViewHolder {
        Log.d(TAG, "MyRecyclerViewAdapter - onCreateViewHolder() called")

        return ChatListViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.layout_chat_item, parent, false))

    }

    // 보여줄 목록 갯수
    override fun getItemCount(): Int {
//        Log.d(TAG, "MyRecyclerViewAdapter - getItemCount() called")
        return chatList.size
    }

    // 뷰와 묶일때
    override fun onBindViewHolder(holder: ChatListViewHolder, position: Int) {
        Log.d(TAG, "MyRecyclerViewAdapter - onBindViewHolder() called / " +
                "position : $position")

        // 해당 번째의 아이템을 가져온다.
        val chatItem = this.chatList[position]
        // 데이터와 뷰 묶음
        holder.bind(chatItem)
    }

    // 외부에서 데이터 넘기기
    fun submitList(chatList: ArrayList<ChatList>){
        Log.d(TAG, "MyRecyclerViewAdapter - submitList() called")
        this.chatList = chatList
    }

}