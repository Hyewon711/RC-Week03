package com.example.myrc_03.model

class CardList (var img: String, var title: String, var price: String)