package com.example.myrc_03

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myrc_03.databinding.ActivityMainBinding
import com.example.myrc_03.fragment.*
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity(), ProfileRecyclerviewInterface {
    private lateinit var binding : ActivityMainBinding
    val TAG: String = "로그"
    // 데이터를 담을 그릇, 배열
    var profileModelList = ArrayList<ProfileModel>()
    private lateinit var profileRecyclerAdapter: ProfileRecyclerAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initBinding()
        setupBottomNavigationView()

        Log.d(TAG, "MainActivity - onCreate() called")
        // item add
        addItem()
        // 어댑터 인스턴스 생성
        profileRecyclerAdapter = ProfileRecyclerAdapter(this)
        profileRecyclerAdapter.submitList(this.profileModelList)

        // 리사이클러뷰 설정
        profile_recyclerview.apply {
            // xml의 profile_recyclerview 방향 등 설정
            layoutManager = LinearLayoutManager(this@MainActivity, LinearLayoutManager.VERTICAL, false)
            // 어댑터 장착
            adapter = profileRecyclerAdapter
        }
    }


    /* 레이아웃 설정 */
    private fun initBinding() {
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }

    fun addItem() {
        Log.d(TAG, "반복문 돌리기 전 this.profileModelList : ${this.profileModelList.size}")

        for (i in 1..30) {
            if (i % 2 == 0) {
                var profileModel =
                    ProfileModel(
                        name = "서혜원 $i",
                        img = "https://image.fmkorea.com/files/attach/new3/20221111/4366334374/716547527/5204698966/423dbeff036e95c59a8b6fb4790cd6c6.png",
                        state = "$i 번째 프로필 입니다."
                    )
                this.profileModelList.add(profileModel)
            } else {
                var profileModel =
                    ProfileModel(
                        name = "서혜원 $i",
                        img = null,
                        state = "$i 번째 프로필 입니다.",
                        song = "사건의 지평선 - 윤하"
                    )
                this.profileModelList.add(profileModel)
            }
            Log.d(TAG, "반복문 돌린 후 this.profileModelList : ${this.profileModelList.size}")
        }
    }

    override fun onItemClicked(position: Int) {
        Log.d(TAG, "MainActivity - onItemClicked() called")
        val title: String = this.profileModelList[position].name ?: ""

        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage("$title 프로필 보기 입니다.")
            .setPositiveButton("확인") { dialog, id ->
            }.show()
    }

    /* BottomNavigationView Fragment Change */
    private fun setupBottomNavigationView() {
        binding.bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.menu_home -> {
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frame_layout, HomeFragment())
                        .commit()
                    true
                }
                R.id.menu_talk -> {
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frame_layout, TalkFragment())
                        .commit()
                    true
                }
                R.id.menu_view -> {
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frame_layout, ViewFragment())
                        .commit()
                    true
                }
                R.id.menu_shop -> {
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frame_layout, ShopFragment())
                        .commit()
                    true
                }
                R.id.menu_user -> {
                        supportFragmentManager.beginTransaction()
                            .replace(R.id.frame_layout, UserFragment())
                            .commit()
                        true
                }
                else -> false
            }
        }
        binding.bottomNav.itemIconTintList = null
    }
}
