package com.example.myrc_03.model

class ChatList (var img: String? = null, var title: String, var content: String? = null, var time: String){

}