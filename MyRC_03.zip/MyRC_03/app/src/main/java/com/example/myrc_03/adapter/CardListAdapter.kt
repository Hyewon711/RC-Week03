package com.example.myrc_03.adapter

import android.content.Context
import android.text.Layout
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.myrc_03.App
import com.example.myrc_03.R
import com.example.myrc_03.model.CardList
import kotlinx.android.synthetic.main.card_item.view.*

class CardListAdapter(private val cardList: ArrayList<CardList>, private val context: Context) : RecyclerView.Adapter<CardListAdapter.CardListViewHolder>() {
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): CardListViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.card_item, parent, false)
        return CardListViewHolder(itemView)
    }

    override fun getItemCount(): Int {
        return cardList.size
    }

    override fun onBindViewHolder(holder: CardListViewHolder, position: Int) {
        // 해당 번째의 아이템을 가져온다.
        val cardItem = this.cardList[position]
        // 데이터와 뷰 묶음
        holder.bind(cardItem)
    }

    // 뷰홀더
    class CardListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val ImageView = itemView.imgList
        private val titleTextView = itemView.textListTitle
        private val priceTextView = itemView.textListPrice

        // 뷰와 데이터를 연결
        fun bind(cardList: CardList){
            titleTextView.text = cardList.title
            priceTextView.text = cardList.price
            ImageView.clipToOutline = true
            // with(context) : context를 전역으로 따로 빼둠,
            // placeholder : 이미지 로딩을 시작하기 전에 보여줄 이미지 설정,
            // fallback : 이미지가 null인 경우 보여줄 이미지 설정
            Glide
                .with(App.instance)
                .load(cardList.img)
                .placeholder(R.drawable.test_img)
                .fallback(R.drawable.no_profile_img)
                .into(ImageView)
        }

    }
}
