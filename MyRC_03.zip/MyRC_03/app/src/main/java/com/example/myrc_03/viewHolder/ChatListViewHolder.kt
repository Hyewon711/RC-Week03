package com.example.myrc_03.viewHolder

import android.util.Log
import android.view.View
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.myrc_03.App
import com.example.myrc_03.R
import com.example.myrc_03.model.ChatList
import kotlinx.android.synthetic.main.layout_chat_item.view.*

class ChatListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    val TAG: String = "로그"
    private val ImageView = itemView.chat_img
    private val TitleTextView = itemView.chat_title
    private val ContentTextView = itemView.chat_content
    private val TimeTextView = itemView.chat_time

    // 뷰와 데이터를 연결
    fun bind(chatList: ChatList){
        TitleTextView.text = chatList.title
        ContentTextView.text = chatList.content
        TimeTextView.text = chatList.time

        // with(context) : context를 전역으로 따로 빼둠,
        // placeholder : 이미지 로딩을 시작하기 전에 보여줄 이미지 설정,
        // fallback : 이미지가 null인 경우 보여줄 이미지 설정
        Glide
            .with(App.instance)
            .load(chatList.img)
            .placeholder(R.drawable.test_img)
            .fallback(R.drawable.no_profile_img)
            .into(ImageView)
    }
}